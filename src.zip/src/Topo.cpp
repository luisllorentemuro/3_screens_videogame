#include "ofMain.h"
#include "Topo.h"

void Topo::setupTopo(ofImage* enemy_image) {
	posTopo.x = ofRandom(1024);
	posTopo.y = ofRandom(768);
	imgTopo = enemy_image;
	widthTopo = imgTopo->getWidth();
	topo_intervalTopo = ofRandom(3, 8);
	start_intervalTopo = ofGetElapsedTimef();
	activoTopo = true;
}
void Topo::updateTopo() {

	if (ofGetElapsedTimef() - start_intervalTopo > topo_intervalTopo) {
		//start_interval = ofGetElapsedTimef();
		//activo = !activo;
		activoTopo = false;
		
	}
}
void Topo::drawTopo() {
	if (activoTopo) {
		imgTopo->draw(posTopo.x - 70.0f, posTopo.y - 70.0f, 2 * 70.0f, 2 * 70.0f);
	}

}
bool Topo::verifyTopo() {
	if (activoTopo) {
		return true;
	}
	return false;
}

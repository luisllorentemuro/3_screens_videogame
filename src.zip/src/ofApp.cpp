#include "ofApp.h"
#include <iostream>
#include <chrono>

using namespace snakelinkedlist;

//--------------------------------------------------------------
void ofApp::setup() {

	ofSetVerticalSync(true);
	ofSetFrameRate(15);

	pixels.allocate(WIDTH, HEIGHT, OF_IMAGE_COLOR);
	fbo.allocate(WIDTH, HEIGHT, GL_RGB);
	streamingSender1.setup();
	streamingSender2.setup();
	streamingSender3.setup();
	streamingSender1.setVideoEncoder("libx264", "ultrafast", AV_PIX_FMT_RGB24, AV_PIX_FMT_YUV420P, WIDTH, HEIGHT, STREAM_FRAMERATE, STREAM_BITRATE);
	streamingSender2.setVideoEncoder("libx264", "ultrafast", AV_PIX_FMT_RGB24, AV_PIX_FMT_YUV420P, WIDTH, HEIGHT, STREAM_FRAMERATE, STREAM_BITRATE);
	streamingSender3.setVideoEncoder("libx264", "ultrafast", AV_PIX_FMT_RGB24, AV_PIX_FMT_YUV420P, WIDTH, HEIGHT, STREAM_FRAMERATE, STREAM_BITRATE);
	//streamingSender1.start("udp://127.0.0.1:1234");

	streamingSender1.start("udp://192.168.0.101:1234");
	streamingSender2.start("udp://192.168.0.102:1234");
	streamingSender3.start("udp://192.168.0.103:1234");

	primeraVezGameOver = 1;
	game_state = "inicio";


	ofAddListener(box2d.contactStartEvents, this, &ofApp::contactStart);
	cargaAudiovisual();


	xPer = 550;
	yPer = 550;

	tama�oX = 100;
	tama�oY = 100;

	primeraVez = 1;
	entreacto = 1;

	bosses[0] = "tesla";
	bosses[1] = "fourier";
	bosses[2] = "anonymous";
	bosses[3] = "superOrdenador";

	vida = 15;
	vidaBoss = 4;

	primeraVezMinijuego = 1;
	userDataCounter = 0;
	dibujoEntreacto = 0;
	bossMuerto = 1;
	endingPrimera = 1;

	fbo.allocate(1024, 768);
	
	// listen on the given port
	ofLog() << "listening for osc messages on port " << PORT;
	oscReceiver.setup(PORT);
	inicializado = 1;

	timerDis = 0;

	//psmove
	psMoveServerClient.initialize("192.168.0.100"); // Initialize the communication with PSMoveService
	psMoveServerClient.register_connected_controllers(true); // Start receiving information about the connected controllers
	psMoveServerClient.start(); // Start updating the controllers status for each new frame and generating events
	ofAddListener(psMoveServerClient.buttonPressedEvent, this, &ofApp::psMoveButtonPressed);
	ofAddListener(psMoveServerClient.buttonReleasedEvent, this, &ofApp::psMoveButtonReleased);
	
	setupMinijuegoCables();
	setupMatatopos();
	setupMinijuegoPuzzle();
	setupMinijuegoSnake();
	setupMinijuegoEspejos();
}


void ofApp::contactStart(ofxBox2dContactArgs& e) {
	if (e.a != NULL && e.b != NULL) {

		// if we collide with the ground we do not
		// want to play a sound. this is how you do that
		if ((e.a->GetType() == b2Shape::e_polygon && e.b->GetType() == b2Shape::e_circle) || (e.a->GetType() == b2Shape::e_circle && e.b->GetType() == b2Shape::e_polygon || e.a->GetType() == b2Shape::e_edge || e.b->GetType() == b2Shape::e_edge)) {

			userData* aData = (userData*)e.a->GetBody()->GetUserData();
			userData* bData = (userData*)e.b->GetBody()->GetUserData();
			
			if (e.a->GetType() == b2Shape::e_polygon) {

				for (int i = 0; i < proyectiles.size(); i++) {

					auto* ud = (userData*)proyectiles[i]->getData();
					
					if (ud->userID == bData->userID) {

						proyectiles.erase(proyectiles.begin() + i);

					}

				}

				for (int i = 0; i < obstaculos.size(); i++) {

					auto* ud = (userData*)obstaculos[i]->getData();

					if (ud->userID == bData->userID) {

						obstaculos.erase(obstaculos.begin() + i);

					}

				}

				for (int i = 0; i < disparos.size(); i++) {

					auto* ud = (userData*)disparos[i]->getData();

					if (ud->userID == aData->userID) {

						disparos.erase(disparos.begin() + i);

					}
				}

			}
			else if (e.a->GetType() == b2Shape::e_circle) {

				for (int i = 0; i < proyectiles.size(); i++) {

					auto* ud = (userData*)proyectiles[i]->getData();

					if (ud->userID == aData->userID) {

						proyectiles.erase(proyectiles.begin() + i);

					}

				}

				for (int i = 0; i < obstaculos.size(); i++) {

					auto* ud = (userData*)obstaculos[i]->getData();

					if (ud->userID == aData->userID) {

						obstaculos.erase(obstaculos.begin() + i);

					}

				}

				for (int i = 0; i < disparos.size(); i++) {

					auto* ud = (userData*)disparos[i]->getData();

					if (ud->userID == bData->userID) {

						disparos.erase(disparos.begin() + i);

					}
				}

			}
			else if ((e.a->GetType() == b2Shape::e_edge || e.b->GetType() == b2Shape::e_edge)) {

				if (e.a->GetType() == b2Shape::e_edge) {

					for (int i = 0; i < proyectiles.size(); i++) {

						auto* ud = (userData*)proyectiles[i]->getData();

						if (ud->userID == bData->userID) {

							proyectiles.erase(proyectiles.begin() + i);

						}

					}

					for (int i = 0; i < obstaculos.size(); i++) {

						auto* ud = (userData*)obstaculos[i]->getData();

						if (ud->userID == bData->userID) {

							obstaculos.erase(obstaculos.begin() + i);

						}

					}

					for (int i = 0; i < disparos.size(); i++) {

						auto* ud = (userData*)disparos[i]->getData();

						if (ud->userID == bData->userID) {

							disparos.erase(disparos.begin() + i);

						}
					}

				}
				else if(e.b->GetType() == b2Shape::e_edge) {

					for (int i = 0; i < proyectiles.size(); i++) {

						auto* ud = (userData*)proyectiles[i]->getData();

						if (ud->userID == aData->userID) {

							proyectiles.erase(proyectiles.begin() + i);

						}

					}

					for (int i = 0; i < obstaculos.size(); i++) {

						auto* ud = (userData*)obstaculos[i]->getData();

						if (ud->userID == aData->userID) {

							obstaculos.erase(obstaculos.begin() + i);

						}

					}

					for (int i = 0; i < disparos.size(); i++) {

						auto* ud = (userData*)disparos[i]->getData();

						if (ud->userID == aData->userID) {

							disparos.erase(disparos.begin() + i);

						}
					}

				}
			}
		}
		
	
	}
}


//--------------------------------------------------------------
void ofApp::update() {

	// update the sound playing system:
	ofSoundUpdate();

	box2d.update();
	oscReceiverPoints();

	if (game_state == "inicio") {
		
		if (primeraVez) {
			ofSleepMillis(5000);
			intro.play();
			primeraVez = 0;
		}
		pantallaX = 1024;
		intro.update();
		fbo.begin();
		intro.draw(0, 0, 1024, 768);
		ofDrawBitmapString(ofToString("Presiona cualquier tecla para saltar la introduccion"), 10, 10);
		ofDrawBitmapString(game_state, 10, 30);
		fbo.end();

	}
	else if (game_state == "menu") {
		
		primeraVez = 1;
		pantallaX = 1024;
		intro.stop();
		fbo.begin();
		menu.draw(0, 0, 1024, 768);
		ofDrawBitmapString(ofToString("Presiona cualquier tecla para comenzar la partida"), 10, 10);
		ofDrawBitmapString(game_state, 10, 30);
		fbo.end();
	}
	else if (game_state == "nivel1") {
		if (primeraVez) {
			musicaFondo.play();
			planta4.play();

		}
		controlJuego(game_state);
		planta4.update();
		ejecucionSalto();
		detectorColision();
		
		fbo.begin();
		ofClear(0, 0, 0);
		ofSetColor(255, 255, 255);
		fboIn();
		dibujarCorazones();
		fbo.end();

	}
	else if (game_state == "nivel2") {
		if (primeraVez) {

			planta3.play();

		}
		controlJuego(game_state);
		planta3.update();
		ejecucionSalto();
		detectorColision();

		fbo.begin();
		ofClear(0, 0, 0);
		ofSetColor(255, 255, 255);
		fboIn();
		dibujarCorazones();
		fbo.end();

	}
	else if (game_state == "nivel3") {
		if (primeraVez) {

			planta2.play();

		}
		controlJuego(game_state);
		planta2.update();
		ejecucionSalto();
		detectorColision();

		fbo.begin();
		ofClear(0, 0, 0);
		ofSetColor(255, 255, 255);
		fboIn();
		dibujarCorazones();
		fbo.end();

	}
	else if (game_state == "nivel4") {
		if (primeraVez) {

			planta1.play();

		}
		controlJuego(game_state);
		planta1.update();
		ejecucionSalto();
		detectorColision();

		fbo.begin();
		ofClear(0, 0, 0);
		ofSetColor(255, 255, 255);
		fboIn();
		dibujarCorazones();
		fbo.end();

	}
	else if (game_state == "nivel5") {
		if (primeraVez) {
			
			ofSetFrameRate(15);
			sotano.play();
			
		}
		controlJuego(game_state);
		sotano.update();
		ejecucionSalto();
		detectorColision();

		fbo.begin();
		ofClear(0, 0, 0);
		ofSetColor(255, 255, 255);
		fboIn();
		dibujarCorazones();
		fbo.end();

	}
	else if (game_state == "gameover") {

		
		proyectiles.erase(proyectiles.begin(), proyectiles.end());
		obstaculos.erase(obstaculos.begin(), obstaculos.end());
		disparos.erase(disparos.begin(), disparos.end());
		
		pantallaX = 1024;
		planta4.firstFrame();
		planta3.firstFrame();
		planta2.firstFrame();
		planta1.firstFrame();
		sotano.firstFrame();
		
		fbo.begin();
		ofClear(0, 0, 0);
		ofSetColor(255, 255, 255);
		fboIn();
		fbo.end();

		musicaFondo.stop();
		if (primeraVezGameOver) {

			efectoGameOver.play();
			primeraVezGameOver = 0;
			primeraVez = 1;
			entreacto = 1;
			vida = 1;
			primeraVezMinijuego = 1;
			userDataCounter = 0;
			dibujoEntreacto = 0;
			bossMuerto = 1;
			endingPrimera = 1;
			timerDis = 0;
			setupMinijuegoCables();
			setupMatatopos();
			setupMinijuegoPuzzle();
			setupMinijuegoSnake();
			setupMinijuegoEspejos();
			inicializado = 1;
		}
		
		
		

	}
	else if (game_state == "minijuego") {

		minijuego = 1;

		pantallaX = 1024;

		if (tipoMinijuego == "cables") {

			minijuegoCablesUpdate();
			if (primeraVezMinijuego) {
				primeraVezMinijuego = 0;
				start_to_game = ofGetElapsedTimef();

			}
			
			//draw cables
			fbo.begin();
			ofClear(0, 0, 0);
			ofSetColor(255, 255, 255);
			drawMinijuegoCables();
			ofDrawCircle(new_x, new_y, 8);
			/*if (agachado == true) {

				ofDrawBitmapString("agachado", 10, 90);

			}
			else {

				ofDrawBitmapString("de pie", 10, 90);

			}*/
			fbo.end();
			
			if (game_stateCables == "end") {

				primeraVezMinijuego = 1;
				game_state = "nivel2";
				ofSleepMillis(2000);
				minijuego = 0;
				primeraVez = 1;

			}
		
		}
		else if (tipoMinijuego == "matatopos") {
			
			updateMatatopos();
			if (primeraVezMinijuego) {
				primeraVezMinijuego = 0;
				start_to_gameMatatopos = ofGetElapsedTimef();

			}
			
			//draw matatopos
			fbo.begin();
			ofClear(0, 0, 0);
			ofSetColor(255, 255, 255);
			drawMatatopos();
			ofDrawCircle(new_x, new_y, 8);
			/*if (agachado == true) {

				ofDrawBitmapString("agachado", 10, 90);

			}
			else {

				ofDrawBitmapString("de pie", 10, 90);

			}*/
			fbo.end();
			
			if (game_stateMatatopos == "end") {

				primeraVezMinijuego = 1;
				game_state = "nivel3";
				ofSleepMillis(2000);
				minijuego = 0;
				primeraVez = 1;

			}

		}
		else if (tipoMinijuego == "puzzle") {
			
			minijuegoPuzzleUpdate();
			if (primeraVezMinijuego) {
				primeraVezMinijuego = 0;
				start_to_game = ofGetElapsedTimef();

			}
			
			//draw matatopos
			fbo.begin();
			ofClear(0, 0, 0);
			ofSetColor(255, 255, 255);
			drawMinijuegoPuzzle();
			ofDrawCircle(new_x, new_y, 8);
			/*if (agachado == true) {

				ofDrawBitmapString("agachado", 10, 90);

			}
			else {

				ofDrawBitmapString("de pie", 10, 90);

			}*/
			fbo.end();

			if (game_statePuzzle == "end") {

				primeraVezMinijuego = 1;
				game_state = "nivel4";
				ofSleepMillis(2000);
				minijuego = 0;
				primeraVez = 1;

			}
		}
		else if (tipoMinijuego == "snake") {
			
			minijuegoSnakeUpdate();
			if (primeraVezMinijuego) {
				primeraVezMinijuego = 0;
				start_to_game = ofGetElapsedTimef();
				ofSetFrameRate(6);
			}
			
			//draw snake
			fbo.begin();
			ofClear(0, 0, 0);
			ofSetColor(255, 255, 255);
			drawMinijuegoSnake();
			ofDrawCircle(new_x, new_y, 8);
			/*if (agachado == true) {

				ofDrawBitmapString("agachado", 10, 90);

			}
			else {

				ofDrawBitmapString("de pie", 10, 90);

			}*/
			fbo.end();
			
			if (game_stateSnake == "end") {

				primeraVezMinijuego = 1;
				game_state = "nivel5";
				ofSleepMillis(2000);
				minijuego = 0;
				primeraVez = 1;
			}
		}
		else if (tipoMinijuego == "espejos") {
			
			minijuegoEspejosUpdate();
			box2dEspejos.update();
			if (primeraVezMinijuego) {
				primeraVezMinijuego = 0;
				start_to_game = ofGetElapsedTimef();

			}
			
			fbo.begin();
			ofClear(0, 0, 0);
			ofSetColor(255, 255, 255);
			drawMinijuegoEspejos();
			ofDrawCircle(new_x, new_y, 8);
			/*if (agachado == true) {

				ofDrawBitmapString("agachado", 10, 90);

			}
			else {

				ofDrawBitmapString("de pie", 10, 90);

			}*/
			fbo.end();

			if (game_stateEspejos == "end") {

				
				primeraVezMinijuego = 1;
				game_state = "final";
				ofSleepMillis(2000);
				minijuego = 0;
				primeraVez = 1;

			}
	
		}

	}
	else{

		fbo.begin();
		ofClear(0, 0, 0);
		fboIn();
		ofDrawCircle(new_x, new_y, 8);
		fbo.end();
	}
	
	psMoveUpdate();
	
	//new_x = mouseX - 1024;
	//new_y = mouseY;
	fbo.readToPixels(pixels);

}


//--------------------------------------------------------------
void ofApp::draw() {
	
	if(pantallaX == 0) {
		


		fbo.draw(pantallaX, pantallaY);
		streamingSender1.sendVideoFrame(pixels.getData());
		pixels.setColor(ofColor::black);
		streamingSender2.sendVideoFrame(pixels.getData());
		pixels.setColor(ofColor::black);
		streamingSender3.sendVideoFrame(pixels.getData());

	} else if (pantallaX == 1024){
		
		fbo.draw(pantallaX, pantallaY);
		streamingSender2.sendVideoFrame(pixels.getData());
		pixels.setColor(ofColor::black);
		streamingSender3.sendVideoFrame(pixels.getData());
		pixels.setColor(ofColor::black);
		streamingSender1.sendVideoFrame(pixels.getData());

	
	} else if (pantallaX == 2048) {
	
		fbo.draw(pantallaX, pantallaY);
		streamingSender3.sendVideoFrame(pixels.getData());
		pixels.setColor(ofColor::black);
		streamingSender1.sendVideoFrame(pixels.getData());
		pixels.setColor(ofColor::black);
		streamingSender2.sendVideoFrame(pixels.getData());


	}
	
	

}

//--------------------------------------------------------------
void ofApp::keyPressed(int key) {

	if (vidaBoss <= 0 && entreacto == 1) {

		entreacto = 0;

	}

	

	if (game_state == "nivel1" || game_state == "nivel2" || game_state == "nivel3" || game_state == "nivel4" || game_state == "nivel5") {

	}if (key == 'w' || key == 'W') {
		salto = true;
	}
	else if (key == 's' || key == 'S') {
		agachado = true;
	}
	else if (key == 'd' || key == 'D') {
		disparoP = true;
	}
	else if (key == 'g' || key == 'G') {
		proyectil1 = true;
		
	}
	else if (key == 'h' || key == 'H') {
		proyectil2 = true;
		
	}
	else if (key == 'j' || key == 'J') {
		proyectil3 = true;
		
	}
	else if (key == 'k' || key == 'K') {
		proyectil4 = true;
		
	}

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key) {

	if (game_state == "inicio") {
		game_state = "menu";
	}
	else if (game_state == "menu") {
		game_state = "nivel1";
	}
	/*else if (game_state == "nivel1") {
		game_state = "nivel2";
	}
	else if (game_state == "nivel2") {
		game_state = "nivel3";
	}
	else if (game_state == "nivel3") {
		game_state = "nivel4";
	}
	else if (game_state == "nivel4") {
		game_state = "nivelsotano";
	}*/

	if (game_state == "gameover") {

		game_state = "menu";

	}

	if (game_state == "nivel1" || game_state == "nivel2" || game_state == "nivel3" || game_state == "nivel4" || game_state == "nivel4") {

	}if (key == 'w' || key == 'W') {
		
	}
	else if (key == 's' || key == 'S') {
		agachado = false;
	
	
	}
}

void ofApp::psMoveButtonPressed(PSMoveEventInfo& eventInfo) {
	
	if (vidaBoss <= 0 && entreacto == 1) {

		entreacto = 0;

	}
	
	if (eventInfo.button == PSMOVE_TRIANGLE_BUTTON) {
		salto = true;
	}
	else if (eventInfo.button == PSMOVE_TRIGGER_BUTTON) {
		psMoveServerClient.reset_orientation(eventInfo.controller_idx);
	}
	else if (eventInfo.button == PSMOVE_CIRCLE_BUTTON) {
		disparoP = true;

	}

	if (game_state == "minijuego") {

		if (tipoMinijuego == "cables") {

			mousePressedCables();
			
			cablesBotonPrieto = true;

		}
		else if (tipoMinijuego == "matatopos") {

			mousePressedMatatopos();

		}
		else if (tipoMinijuego == "puzzle") {

			if (eventInfo.button == PSMOVE_SQUARE_BUTTON ) {
				keyC = true;

			}
			if (eventInfo.button == PSMOVE_TRIANGLE_BUTTON) {
				keyX = true;

			}

		}
		else if (tipoMinijuego == "snake") {

			if (eventInfo.button == PSMOVE_SQUARE_BUTTON) {
				keyS = 'W';

			}
			if (eventInfo.button == PSMOVE_TRIANGLE_BUTTON) {
				keyS = 'D';

			}
			if (eventInfo.button == PSMOVE_CROSS_BUTTON) {
				keyS = 'A';

			}
			if (eventInfo.button == PSMOVE_CIRCLE_BUTTON) {
				keyS = 'S';

			}

			keyPressedSnake(keyS);

		}
		else if (tipoMinijuego == "espejos") {

			pretadoEspejos = true;

			if (eventInfo.button == PSMOVE_CROSS_BUTTON) {
				auto lacasito = make_shared<Lacasito>();
				lacasito->setPhysics(0.1, 0.0001, 50);
				lacasito->setup(box2dEspejos.getWorld(), new_x, new_y, RADIO_LACASITO);
				lacasito->color = ofRandom(0, 4);

				lacasitos.push_back(lacasito);

			}

		}

	}

}

void ofApp::psMoveButtonReleased(PSMoveEventInfo& eventInfo) {
	
	if (game_state == "inicio") {
		game_state = "menu";
	}
	else if (game_state == "menu") {
		game_state = "nivel1";
	}
	else if (game_state == "gameover") {

		game_state = "menu";
		primeraVezGameOver = 1;
	}

	if (tipoMinijuego == "cables") {

		mouseReleasedCables();
		cablesBotonPrieto = false;

	}
	else if (tipoMinijuego == "espejos"){

		pretadoEspejos = false;

	}

}



//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y) {

	mouseX = x;
	mouseY = y;

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button) {

	if (game_state == "minijuego") {

		if (tipoMinijuego == "cables") {

			

		}


	}

}








//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button) {

	if (game_state == "minijuego") {

		if (tipoMinijuego == "cables") {

			

		}


	}


}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button) {

	if (game_state == "minijuego") {

		if (tipoMinijuego == "cables") {

			

		}


	}

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y) {

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y) {

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h) {
	if (tipoMinijuego == "snake") {

		windowResizedSnake(w, h);

	}


}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg) {

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo) {

}

void ofApp::exit() {

	psMoveServerClient.close();

}
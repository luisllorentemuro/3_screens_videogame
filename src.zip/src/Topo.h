#pragma once

#include "ofMain.h"
#include "ofxBox2d.h"

class Topo
{
public:
	ofPoint posTopo;
	float speedTopo;
	float amplitudeTopo;
	float widthTopo;

	void setupTopo(ofImage* enemy_image);
	void updateTopo();
	void drawTopo();
	bool verifyTopo();

	float start_intervalTopo;
	float topo_intervalTopo;

	ofImage* imgTopo;

	bool activoTopo=true;
};



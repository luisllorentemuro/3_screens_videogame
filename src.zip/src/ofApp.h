#pragma once
#include <ctime>
#include <cstdlib>
#include <utility>
#include "Topo.h"


#pragma once
#include "ofxBox2d.h"
#include "ofxOsc.h"
#include "ofMain.h"
#include "ofxPSMoveService.h"
#include "ofxQuadWarp.h"
#include "ofxOpenCv.h"
#include "snake.h"
#include "SnakeFood.h"
#include "ofxStreamingSender.h"
#define RADIO 30.0f
#define LADO_DISPARO 50.0f
#define N_LACASITOS 4
#define RADIO_LACASITO 30.0f
#define WIDTH 1024
#define HEIGHT 768
#define STREAM_FRAMERATE 60
#define STREAM_BITRATE 4000000


namespace snakelinkedlist {

	// Enum to represent the current state of the game
	enum GameState {
		IN_PROGRESS = 0,
		PAUSED,
		FINISHED
	};

	// listening port
#define PORT 8000


	class userData {
	public:
		int	 userID;

	};

	class Lacasito : public ofxBox2dCircle {
	public:
		int color;
	};

	class Sugus : public ofxBox2dRect {
	public:
		int color;
	};

	class Disparo : public ofxBox2dRect {
	public:

	};

	class Proyectil : public ofxBox2dCircle {
	public:
		int tipo;

	};

	class Obstaculo : public ofxBox2dCircle {
	public:
		int tipo;

	};

	class ofApp : public ofBaseApp {

	public:
		void setup();
		void update();
		void draw();

		void keyPressed(int key);
		void keyReleased(int key);
		void mouseMoved(int x, int y);
		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased(int x, int y, int button);
		void mouseEntered(int x, int y);
		void mouseExited(int x, int y);
		void windowResized(int w, int h);
		void dragEvent(ofDragInfo dragInfo);
		void gotMessage(ofMessage msg);
		void controlJuego(string gamePhase);
		void cargaAudiovisual();
		void ejecucionSalto();
		void drawPersonaje();
		void drawDisparos();
		void drawObstaculosProyectiles(int posicion, ofImage proyectil[2]);
		void disparoPersonaje();
		void proyectilesObstaculos();
		void drawPeleaBoss(string nombre);
		void peleaBoss(string nombre);
		void generacionProyectilesObstaculos();
		void contactStart(ofxBox2dContactArgs& e);
		void colisionBoss();
		void setupMinijuegoCables();
		void drawMinijuegoCables();
		void minijuegoCablesUpdate();
		void mouseDraggedCables();
		void mousePressedCables();
		void mouseReleasedCables();
		void entreactoDraw();
		void fboIn();
		void cambioPantalla();
		void oscReceiverPoints();
		void setupMatatopos();
		void updateMatatopos();
		void drawMatatopos();
		void mousePressedMatatopos();
		void setupMinijuegoPuzzle();
		void drawMinijuegoPuzzle();
		void minijuegoPuzzleUpdate();
		void keyPressedPuzzle(int key);
		void setupMinijuegoSnake();
		void drawMinijuegoSnake();
		void minijuegoSnakeUpdate();
		void keyPressedSnake(int key);
		void windowResizedSnake(int w, int h);
		void dibujarCorazones();
		void exit();

		//control del juego
		string game_state;
		ofImage menu;
		ofVideoPlayer intro;
		bool videoAcabado;
		bool inicializacion = true;
		bool continua;
		bool flag;
		int mouseX, mouseY;
		int z = 0;
		int posicionP0;
		bool primeraVez;
		float timer;
		ofImage entreactoI, gameOver, ending, ending2, entreactonivel1, entreactonivel2, entreactonivel3, entreactonivel4, entreactosotano,corazon;
		bool entreacto, continuar;
		bool minijuego;
		string tipoMinijuego;
		bool primeraVezMinijuego;
		int userDataCounter;
		bool dibujoEntreacto;
		bool endingPrimera;
		bool primeraVezGameOver;

		//proyectiles y obstaculos
		bool proyectil1, proyectil2, proyectil3, proyectil4;
		vector <ofPtr<Proyectil> > proyectiles;
		vector <ofPtr<Obstaculo> > obstaculos;
		ofVec2f point;
		ofImage ComProyectil1, ComProyectil2, ComObstaculo1, ComObstaculo2, ArmaCom, ElecProyectil1, ElecProyectil2, ElecObstaculo1, ElecObstaculo2, ArmaElec,
			InfProyectil1, InfProyectil2, InfObstaculo1, InfObstaculo2, ArmaInf, TelProyectil1, TelProyectil2, TelObstaculo1, TelObstaculo2, ArmaTel, ArmaSot;
		ofImage proyectil[2], obstaculo[2];
		ofImage proyectilesElec[2], obstaculosElec[2], proyectilesTel[2], obstaculosTel[2], proyectilesCom[2], obstaculosCom[2], proyectilesInf[2], obstaculosInf[2];
		ofImage  disparo;


		//personaje 
		int vida;
		bool salto, agachado, disparoP;
		static const int imageNum = 2;
		int  imageNo = 0, counterLimit = 0, counter;
		ofImage image[imageNum];
		ofImage principalQuieto, principalAgachado;
		ofImage personaje, prueba;
		int pos;
		float xPer, yPer;
		double contador, resta;

		//detector colisiones

		void detectorColision();
		int colisiones;

		//mapas
		ofVideoPlayer planta1, planta2, planta3, planta4, sotano;
		ofVideoPlayer escenario;


		//box2d
		ofxBox2d box2d;

		//vector <ofPtr<Personaje> > personajes;

		vector <ofPtr<Disparo> > disparos;

		//bosses
		int vidaBoss;
		ofImage boss, tesla, fourier, anonymous, superOrdenador, adaByron;
		float enemyY, enemyX, w;
		string nombreBoss;
		int tama�oX, tama�oY;
		bool firstTime;
		float timerAda;
		string bosses[4];
		int index = 0;
		string nombreBossD;

		//minijuegoCables
		ofImage img;
		ofVec3f p;
		ofVec3f cable;
		ofVec3f cable1;
		ofVec3f cable2;
		ofVec3f cable3;
		ofVec3f cable4;
		ofVec3f p1;
		ofVec3f p2;
		ofVec3f p3;
		ofVec3f p4;
		bool estoyPintando;
		bool rojo;
		bool amarillo;
		bool morado;
		bool azul;
		string color;
		string game_stateCables;
		float start_to_game;
		float interval_to_start;
		vector<float> cables_random;
		vector<float> posiciones;
		float pos_rojo;
		float pos_azul;
		float pos_amarillo;
		float pos_morado;
		ofImage img_roja;
		ofImage img_azul;
		ofImage img_amarilla;
		ofImage img_morada;
		bool cablesBotonPrieto;

		//fbo
		ofFbo fbo;

		//cambioPantalla
		double timerCambio;
		int numeroR;
		int pantallaX, pantallaY;

		//mediaPipe
		ofxOscReceiver oscReceiver;

		bool is_tracking_pose = false;
		bool is_tracking_face = false;
		bool is_tracking_left_hand = false;
		bool is_tracking_right_hand = false;
		ofPoint left_shoulder, left_elbow, left_wrist, right_shoulder, right_elbow, right_wrist, face_nose, right_hip, left_hip, right_knee, left_knee, right_ankle, left_ankle, right_heel, left_heel, right_foot, left_foot;


		//booleans
		bool inicializado = true;

		float phi1 = 1.2; //Umbral 
		float phi2 = 1; //Umbral
		float phi3 = 0;
		float t0, t1, duration;
		float derivada = 0;
		float ultimo_punto = 0;

		ofPoint calibracion_inicial;
		ofPoint agachado_ultimo;

		void inicializacionOsc(ofPoint point);
		void detAgachado(ofPoint point);

		//psmove
		void psMoveButtonPressed(PSMoveEventInfo& eventInfo);
		void psMoveUpdate();
		void psMoveButtonReleased(PSMoveEventInfo& eventInfo);

		ofImage image_PSMSAngles;
		ofImage image_navigationAngles;
		ofImage image_orientationVector;

		ofxPSMoveServiceClient psMoveServerClient;
		int controller_in_screen = 0;

		ofVec3f PSMSAngles;
		ofVec3f navigationAngles;
		ofVec3f orientationVector;

		float new_x;
		float new_y;

		int desfase = 0;

		bool izquierda = 0, derecha = 0;

		//Minijuego matatopos
		ofImage enemy_image;
		ofImage martillo;
		ofImage start_screen;
		int cont;
		int score;
		int score_total;
		int topos_size;
		float width_topo;
		string game_stateMatatopos;
		float start_to_gameMatatopos;
		float interval_to_startMatatopos;
		float pos_x_martillo;
		float pos_y_martillo;
		vector<Topo> topos;
		Topo topo;

		//minijuegoPuzzle
		static const int N_X = 3;
		static const int N_Y = 2;
		int dist_X;
		int dist_Y;
		int x;
		int y;
		int wPuzzle;
		int h;
		int i;
		int j;
		int on;
		int pieza;
		int direccion;
		int cnt;

		//Pieza 1
		int Posx;
		int Posy;
		int cnt1;
		ofImage Imagen;
		//Pieza 2
		ofImage Imagen2;
		int Pos1x;
		int Pos1y;
		int cnt2;
		//Pieza3
		ofImage Imagen3;
		int Pos2x;
		int Pos2y;
		int cnt3;
		//Pieza4
		ofImage Imagen4;
		int Pos3x;
		int Pos3y;
		int cnt4;
		//Pieza5
		ofImage Imagen5;
		int Pos4x;
		int Pos4y;
		int cnt5;
		//Pieza6
		ofImage Imagen6;
		int Pos5x;
		int Pos5y;
		int cnt6;

		ofImage imgs[N_X][N_Y];
		ofxQuadWarp warper[N_X][N_Y];
		ofImage imgPuzzle;
		ofSoundPlayer sound;

		//YouWin
		ofImage UWin;

		//ofFbo fbo;

		bool keyC = false;
		bool keyX = false;

		ofImage piezas[9];

		string game_statePuzzle;

		//minijuegoSnake
		std::vector<int> gameScores;
		GameState current_state_ = IN_PROGRESS; // The current state of the game, used to determine possible actions
		Snake game_snake_; // The object that represents the user controlled snake
		SnakeFood game_food_; // The object that represents the food pellet the user is attempting to eat with the snake
		bool pressedH = false;
		bool should_update_ = true;     // A flag boolean used in the update() function. Due to the frame dependent animation we've
										// written, and the relatively low framerate, a bug exists where users can prefire direction 
										// changes faster than a frame update. Our solution is to force a call to update on direction
										// changes and then not update on the next frame to prevent the snake from skipping across the screen.


		// Private helper methods to render various aspects of the game on screen.
		void drawFood();
		void drawSnake();
		void drawGameOver();
		void drawGamePaused();
		void drawTopTen(); //helps create the table of high scores

		// Resets the game objects to their original state.
		void reset();
		void updateScores();

		// Variables
		int speed = 13;
		ofSoundPlayer gameSound;
		ofImage goodjob;

		string game_stateSnake;

		int keyS;
		
		//minijuegoEspejos
		// this is the function for contacts
		/*void contactStartEspejos(ofxBox2dContactArgs& e);
		void contactEnd(ofxBox2dContactArgs& e);*/

		// when the ball hits we play this sound
		ofSoundPlayer  soundEspejos;

		ofImage youWin;
		ofImage cielo;
		ofImage mirror;
		ofImage cannon;
		ofImage antenna;
		ofImage antenna2;
		ofImage lacasito_prueba;
		ofImage lacasitosImagenes[N_LACASITOS];
		ofxBox2d box2dEspejos;
		vector <shared_ptr<Lacasito>> lacasitos;
		vector <shared_ptr<Sugus>> sugus;
		bool contacto;
		int posXPuzzle;
		int posYPuzzle;
		int mouseXPuzzle;
		int mouseYPuzzle;
		int coordX;
		int coordY;
		string game_stateEspejos;
		bool endEspejos = false;
		bool pretadoEspejos = true;

		void setupMinijuegoEspejos();
		void drawMinijuegoEspejos();
		void minijuegoEspejosUpdate();
		void mouseDraggedEspejos();

		//timer disparo

		double timerDis;
	
		//sonido

		ofSoundPlayer musicaFondo, efectoBossMuerto, efectoDa�oBoss, efectoDisparo, efectoEnding, efectoGameOver, efectoHurt;
		bool bossMuerto;

		//Streaming
		ofPixels pixels;
		ofxStreamingSender streamingSender1;
		ofxStreamingSender streamingSender2;
		ofxStreamingSender streamingSender3;

	};
}



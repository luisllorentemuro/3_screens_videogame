#include "ofApp.h"

using namespace snakelinkedlist;

void ofApp::cargaAudiovisual() {
	
	//personaje
	counter = 0;
	imageNo = 0;
	image[0].loadImage("Principal1.png");
	image[1].loadImage("Principal2.png");
	principalQuieto.loadImage("PrincipalQuieto.png");
	principalAgachado.loadImage("PrincipalAgachado.png");
	prueba.loadImage("prueba.png");


	//intro
	intro.load("Intro.webm");
	intro.setLoopState(OF_LOOP_NORMAL);
	//intro.play();
	menu.load("menu.jpeg");
	entreactoI.load("prueba.jpg");
	gameOver.load("gameover.jpg");
	ending.load("ending.jpeg");
	ending2.load("ending2.jpeg");
	entreactonivel1.load("entreactonivel1.jpeg");
	entreactonivel2.load("entreactonivel2.jpeg");
	entreactonivel3.load("entreactonivel3.jpeg");
	entreactonivel4.load("entreactonivel4.jpeg");
	entreactosotano.load("entreactosotano.jpeg");
	corazon.load("corazon.png");

	//mapas
	planta4.load("planta4.webm");
	planta4.setLoopState(OF_LOOP_NONE);
	planta4.setSpeed(10);
	//planta4.play();
	planta3.load("planta3.webm");
	planta3.setLoopState(OF_LOOP_NONE);
	planta3.setSpeed(10);
	//planta3.play();
	planta2.load("planta2.webm");
	planta2.setLoopState(OF_LOOP_NONE);
	planta2.setSpeed(10);
	//planta2.play();
	planta1.load("planta1.webm");
	planta1.setLoopState(OF_LOOP_NONE);
	planta1.setSpeed(10);
	//planta1.play();
	sotano.load("planta0.webm");
	sotano.setLoopState(OF_LOOP_NONE);
	sotano.setSpeed(10);
	//sotano.play();
	

	//box2d
	box2d.init();
	box2d.setGravity(0, 10);
	box2d.createGround(0, 750, 1024, 768);
	box2d.setFPS(60.0);
	box2d.registerGrabbing();
	box2d.enableEvents();

	//armas obstaculos y proyectiles

	proyectilesCom[0].loadImage("ComProyectil1.png");
	proyectilesCom[1].loadImage("ComProyectil2.png");
	obstaculosCom[0].loadImage("ComObstaculo1.png");
	obstaculosCom[1].loadImage("ComObstaculo2.png");
	ArmaCom.loadImage("ArmaCom.png");

	proyectilesElec[0].loadImage("ElecProyectil1.png");
	proyectilesElec[1].loadImage("ElecProyectil2.png");
	obstaculosElec[0].loadImage("ElecObstaculo1.png");
	obstaculosElec[1].loadImage("ElecObstaculo2.png");
	ArmaElec.loadImage("ArmaElec.png");

	proyectilesInf[0].loadImage("InfProyectil1.png");
	proyectilesInf[1].loadImage("InfProyectil2.png");
	obstaculosInf[0].loadImage("InfObstaculo1.png");
	obstaculosInf[1].loadImage("InfObstaculo2.png");
	ArmaInf.loadImage("ArmaInf.png");

	proyectilesTel[0].loadImage("TelProyectil1.png");
	proyectilesTel[1].loadImage("TelProyectil2.png");
	obstaculosTel[0].loadImage("TelObstaculo1.png");
	obstaculosTel[1].loadImage("TelObstaculo2.png");
	ArmaTel.loadImage("ArmaTel.png");

	ArmaSot.loadImage("ArmaSot.png");

	//boss
	tesla.loadImage("tesla.png");
	fourier.loadImage("fourier.png");
	anonymous.loadImage("anonymous.png");
	superOrdenador.loadImage("SuperOrdenadorSad.png");
	adaByron.loadImage("adabyron.png");

	//sonido 
	musicaFondo.load("musicaFondo.mp3");
	efectoBossMuerto.load("efectoBossMuerto.ogg");
	efectoDa�oBoss.load("efectoDa�oBoss.ogg");
	efectoDisparo.load("efectoDisparo.ogg");
	efectoEnding.load("efectoEnding.ogg");
	efectoGameOver.load("efectoGameOver.ogg");
	efectoHurt.load("efectoHurt.ogg");

	musicaFondo.setVolume(0.5f);
	efectoBossMuerto.setVolume(0.75f);
	efectoDa�oBoss.setVolume(0.75f);
	efectoDisparo.setVolume(0.75f);
	efectoEnding.setVolume(0.75f);
	efectoGameOver.setVolume(0.75f);
	efectoHurt.setVolume(0.75f);

	musicaFondo.setMultiPlay(true);
	efectoBossMuerto.setMultiPlay(true);
	efectoDa�oBoss.setMultiPlay(true);
	efectoDisparo.setMultiPlay(true);
	efectoEnding.setMultiPlay(true);
	efectoGameOver.setMultiPlay(true);
	efectoHurt.setMultiPlay(true);

	musicaFondo.setLoop(true);
}

void ofApp::entreactoDraw() {

	if (game_state == "nivel1") {
		
		entreactonivel1.draw(0,0,1024,768);
	
	}
	else if (game_state == "nivel2") {
	
		entreactonivel2.draw(0, 0, 1024, 768);
	
	}
	else if (game_state == "nivel3") {

		entreactonivel3.draw(0, 0, 1024, 768);

	}
	else if (game_state == "nivel4") {

		entreactonivel4.draw(0, 0, 1024, 768);

	}
	else if (game_state == "nivel5") {

		entreactosotano.draw(0, 0, 1024, 768);

	}

}



void ofApp::detectorColision() {

	for (int i = 0; i < proyectiles.size(); i++) {

		point = proyectiles[i]->getPosition();

		if (agachado) {

			if ((point.x > xPer+40 && point.x < xPer+80) && (point.y > yPer+70 && point.y < yPer+150)) {

				proyectiles.erase(proyectiles.begin() + i);
				colisiones++;

				vida--;
				efectoHurt.play();
			}

		}
		else {

			if ((point.x > xPer && point.x < xPer+80) && (point.y > yPer && point.y < yPer+150)) {

				proyectiles.erase(proyectiles.begin() + i);
				colisiones++;

				vida--;
				efectoHurt.play();
			}

		}

	}

	for (int i = 0; i < obstaculos.size(); i++) {

		point = obstaculos[i]->getPosition();

		if (agachado) {

			if ((point.x > xPer + 40 && point.x < xPer + 80) && (point.y > yPer + 70 && point.y < yPer + 150)) {

				obstaculos.erase(obstaculos.begin() + i);
				colisiones++;

				vida--;
				efectoHurt.play();
			}

		}
		else {

			if ((point.x > xPer && point.x < xPer + 80) && (point.y > yPer && point.y < yPer + 150)) {

				obstaculos.erase(obstaculos.begin() + i);
				colisiones++;

				vida--;
				efectoHurt.play();
			}

		}

	}

}

void ofApp::ejecucionSalto() {

	if (salto) {

		if (flag) {
			flag = 0;
			contador = ofGetElapsedTimef();
		}

		yPer = sin(ofGetElapsedTimef() - contador);
		yPer = ofMap(yPer, -1, 1, 550, 350);

		resta = ofGetElapsedTimef() - contador;

		if (resta >= 1) {
			flag = 1;
			salto = 0;
			yPer = 550;
		}

	}

}

void ofApp::drawPersonaje() {

	if (!videoAcabado && !agachado && !salto) {

		image[imageNo].draw(xPer, yPer, 80, 150);
		counter++;
		if (counter >= counterLimit) {
			counter = 0;
			imageNo++;
			if (imageNo >= imageNum) imageNo = 0;
		}
	}
	else if (agachado) {

		principalAgachado.draw(xPer + 40, yPer + 70, 40, 80);

	}
	else if (salto) {

		image[imageNo].draw(xPer, yPer, 80, 150);

	}

	else {

		principalQuieto.draw(xPer, yPer, 80, 150);

	}

}

void ofApp::drawDisparos() {

	for (int i = 0; i < disparos.size(); i++) {
		ofPushMatrix();
		ofTranslate(disparos[i]->getPosition().x, disparos[i]->getPosition().y, 0);
		ofRotate(disparos[i]->getRotation(), 0, 0, 1);
		disparo.draw(-LADO_DISPARO/2, -LADO_DISPARO / 2, LADO_DISPARO , LADO_DISPARO );
		ofPopMatrix();

	}

}




void ofApp::drawObstaculosProyectiles(int posicionPO,ofImage proyectilf[2]) {

	if (posicionPO == 1||posicionPO==2) {

		for (int i = 0; i < proyectiles.size(); i++) {
			ofPushMatrix();
			ofTranslate(proyectiles[i]->getPosition().x, proyectiles[i]->getPosition().y, 0);
			ofRotate(proyectiles[i]->getRotation(), 0, 0, 1);
			if (proyectiles[i]->tipo == 1) {
				proyectilf[0].draw(-RADIO,-RADIO,RADIO*2,RADIO*2);
			}
			else {
				proyectilf[1].draw(-RADIO, -RADIO, RADIO * 2, RADIO * 2);
			}

			ofPopMatrix();

		}

	}
	else if (posicionPO == 3||posicionPO==4) {

		for (int i = 0; i < obstaculos.size(); i++) {
			ofPushMatrix();
			ofTranslate(obstaculos[i]->getPosition().x, obstaculos[i]->getPosition().y, 0);
			ofRotate(obstaculos[i]->getRotation(), 0, 0, 1);
			if (obstaculos[i]->tipo == 1) {
				proyectilf[0].draw(-RADIO, -RADIO, RADIO * 2, RADIO * 2);
			}
			else {
				proyectilf[1].draw(-RADIO, -RADIO, RADIO * 2, RADIO * 2);
			}

			ofPopMatrix();

		}

	}
	

}


void ofApp::disparoPersonaje() {
	
	
	if (ofGetElapsedTimef() - timerDis <= 1) {

		disparoP = false;
		
	}

	if (disparoP) {

		auto disparo = make_shared<Disparo>();
		disparo->setPhysics(3.0, 0.53, 0.1);
		disparo->setup(box2d.getWorld(), xPer, yPer, LADO_DISPARO,LADO_DISPARO);
		disparo->body->ApplyLinearImpulse(b2Vec2((new_x - xPer)*1.3, (new_y - yPer)*1.3), disparo->body->GetWorldCenter(), true);
		disparo->body->SetUserData(this);
		
		disparo->setData(new userData());
		auto* ud = (userData*)disparo->getData();
		ud->userID = userDataCounter;
		
		disparos.push_back(disparo);
		disparoP = false;
		userDataCounter++;
		
		timerDis = ofGetElapsedTimef();
		efectoDisparo.play();
	}

}


void ofApp:: proyectilesObstaculos(){

	if (proyectil1) {

		auto proyectil = make_shared<Proyectil>();
		proyectil->setPhysics(3.0, 0.53, 0.1);
		proyectil->setup(box2d.getWorld(), 0, 0,RADIO);
		proyectil->tipo = ofRandom(0, 2);
		proyectil->body->ApplyLinearImpulse(b2Vec2(265*0.9, 210*0.9), proyectil->body->GetWorldCenter(), true);
		proyectil->body->SetUserData(this);
		
		proyectil->setData(new userData());
		auto* ud = (userData*)proyectil->getData();
		ud->userID = userDataCounter;

		proyectiles.push_back(proyectil);
		proyectil1 = false;
		userDataCounter++;

	}

	if (proyectil2) {

		auto proyectil = make_shared<Proyectil>();
		proyectil->setPhysics(3.0, 0.53, 0.1);
		proyectil->setup(box2d.getWorld(), 1024, 0,RADIO);
		proyectil->tipo = ofRandom(0, 2);
		proyectil->body->ApplyLinearImpulse(b2Vec2(-237*0.8, 285*0.8), proyectil->body->GetWorldCenter(), true);
		proyectil->body->SetUserData(this);
		
		proyectil->setData(new userData());
		auto* ud = (userData*)proyectil->getData();
		ud->userID = userDataCounter;
		
		proyectiles.push_back(proyectil);
		proyectil2 = false;
		userDataCounter++;

	}

	if (proyectil3) {

		auto obstaculo = make_shared<Obstaculo>();
		obstaculo->setPhysics(3.0, 0.53, 0.1);
		obstaculo->setup(box2d.getWorld(), 0, 550, RADIO);
		obstaculo->tipo = ofRandom(0, 2);
		obstaculo->body->ApplyLinearImpulse(b2Vec2(325, 50), obstaculo->body->GetWorldCenter(), true); //650 100
		obstaculo->body->SetUserData(this);
		
		obstaculo->setData(new userData());
		auto* ud = (userData*)obstaculo->getData();
		ud->userID = userDataCounter;
		
		obstaculos.push_back(obstaculo);
		proyectil3 = false;
		userDataCounter++;

	}

	if (proyectil4) {

		auto obstaculo = make_shared<Obstaculo>();
		obstaculo->setPhysics(3.0, 0.53, 0.1);
		obstaculo->setup(box2d.getWorld(), 1024, 550, RADIO);
		obstaculo->tipo = ofRandom(0, 2);
		obstaculo->body->ApplyLinearImpulse(b2Vec2(-250, 30), obstaculo->body->GetWorldCenter(), true);
		obstaculo->body->SetUserData(this);
		
		obstaculo->setData(new userData());
		auto* ud = (userData*)obstaculo->getData();
		ud->userID = userDataCounter;
		
		obstaculos.push_back(obstaculo);
		proyectil4 = false;
		userDataCounter++;

	}

}


void ofApp::peleaBoss(string nombre) {

	if (nombre == "tesla") {

		enemyY = sin(2 * ofGetElapsedTimef());
		enemyY = ofMap(enemyY, -1, 1, 0, 200);

		enemyX = cos(0.8 * ofGetElapsedTimef());
		enemyX = ofMap(enemyX, -1, 1, 0, 300);

	}
	else if (nombre == "fourier") {

		enemyX = sin( 0.8*ofGetElapsedTimef());
		enemyX = ofMap(enemyX, -1, 1, 200, 900);

		if ((enemyX >= 200 && enemyX <= 900)) {

			w = ofMap(enemyX, 200, 900, 0, PI);

			enemyY = sin(w);
			enemyY = ofMap(enemyY, 0, 1, 700, 100);

		}
		else {

			enemyY = 500;

		}

	}
	else if (nombre == "anonymous") {

		enemyX = sin(0.8* ofGetElapsedTimef());
		enemyX = ofMap(enemyX, -1, 1, 50, 450);

		if ((enemyX >= 150 && enemyX <= 400)) {

			w = ofMap(enemyX, 150,400, 0, PI);

			enemyY = sin(w);
			enemyY = ofMap(enemyY, 0, 1, 400, 100);

		}
		else {
		
			enemyY = 400;

		}

	}
	else if (nombre == "superOrdenador") {

		enemyY = sin(2 * ofGetElapsedTimef());
		enemyY = 100 + ofMap(enemyY, -1, 1, 0, 200);

		enemyX = cos(2 * ofGetElapsedTimef());
		enemyX = 80 + ofMap(enemyX, -1, 1, 0, 300);

	}

}

void ofApp::drawPeleaBoss(string nombre) {

	if (nombre == "tesla") {

		tesla.draw(enemyX, enemyY, tama�oX, tama�oY);

	}
	else if (nombre == "fourier") {

		fourier.draw(enemyX, enemyY, tama�oX, tama�oY);

	}
	else if (nombre == "anonymous") {

		anonymous.draw(enemyX, enemyY, tama�oX, tama�oY);

	}
	else if (nombre == "superOrdenador") {

		superOrdenador.draw(enemyX, enemyY, tama�oX, tama�oY);

	}
	else if (nombre == "adaByron") {

		adaByron.draw(enemyX, enemyY, tama�oX, tama�oY);

	}


}

void ofApp::generacionProyectilesObstaculos() {

	float spawn = ofRandom(5,6);
	int ca�on = ofRandom(0, 5);

	if (ofGetElapsedTimef() - timer >= spawn) {

		if (ca�on == 1) {

			proyectil1 = true;
			timer = ofGetElapsedTimef();
		}
		else if (ca�on == 2) {

			proyectil2 = true;
			timer = ofGetElapsedTimef();
		}
		else if (ca�on == 3) {

			proyectil3 = true;
			timer = ofGetElapsedTimef();
		}
		else if (ca�on == 4) {

			proyectil4 = true;
			timer = ofGetElapsedTimef();
		}

	}
}

void ofApp::colisionBoss() {

	for (int i = 0; i < disparos.size(); i++) {

		point = disparos[i]->getPosition();

		if (videoAcabado) {

			if ((point.x > enemyX && point.x < enemyX + tama�oX) && (point.y > enemyY && point.y < enemyY+tama�oY)) {

				disparos.erase(disparos.begin() + i);
				colisiones++;
				vidaBoss--;
				efectoDa�oBoss.play();
			}

		}
		
	}

}


void ofApp::controlJuego(string gamePhase) {
	if (gamePhase == "nivel1") {

		nombreBoss = "tesla";
		nombreBossD = "tesla";
		escenario = planta4;
		disparo = ArmaElec;
		proyectil[0] = proyectilesElec[0];
		proyectil[1] = proyectilesElec[1];
		obstaculo[0] = obstaculosElec[0];
		obstaculo[1] = obstaculosElec[1];
		videoAcabado = escenario.getIsMovieDone();

		cambioPantalla();

		if (primeraVez) {

			primeraVez = 0;
			timer = ofGetElapsedTimef();
			vidaBoss = 4;
			entreacto == 1;
			numeroR = 1;
		}

		

		ofRemove(disparos, ofxBox2dBaseShape::shouldRemoveOffScreen);
		ofRemove(obstaculos, ofxBox2dBaseShape::shouldRemoveOffScreen);
		ofRemove(proyectiles, ofxBox2dBaseShape::shouldRemoveOffScreen);
		disparoPersonaje();
		generacionProyectilesObstaculos();
		proyectilesObstaculos();

		if (videoAcabado) {

			peleaBoss(nombreBoss);

			if (vidaBoss <= 0 && entreacto == 1) {

				if (bossMuerto) {
					efectoBossMuerto.play();
					bossMuerto = 0;
				}
				
				pantallaX = 1024;
				cambioPantalla();
				dibujoEntreacto = 1;
				proyectiles.erase(proyectiles.begin(), proyectiles.end());
				obstaculos.erase(obstaculos.begin(), obstaculos.end());
				disparos.erase(disparos.begin(), disparos.end());
				
				
			}
			else if (vidaBoss <= 0 && entreacto == 0) {
				
				bossMuerto = 1;
				dibujoEntreacto = 0;
				game_state = "minijuego";
				tipoMinijuego = "cables";//cables
				primeraVezMinijuego = 1;
				
			}
		}

		if (vida == 0) {

			game_state = "gameover";

		}

	}
	else if (gamePhase == "nivel2") {
				
			nombreBoss = "fourier";
			nombreBossD = "fourier";
			escenario = planta3;
			disparo = ArmaCom;
			proyectil[0] = proyectilesCom[0];
			proyectil[1] = proyectilesCom[1];
			obstaculo[0] = obstaculosCom[0];
			obstaculo[1] = obstaculosCom[1];
			videoAcabado = escenario.getIsMovieDone();

			cambioPantalla();

			if (primeraVez) {

				primeraVez = 0;
				timer = ofGetElapsedTimef();
				vidaBoss = 4;
				entreacto = 1;
				numeroR = 1;
			}

			
			disparoPersonaje();
			generacionProyectilesObstaculos();
			proyectilesObstaculos();

			if (videoAcabado) {

				peleaBoss(nombreBoss);

				if (vidaBoss <= 0 && entreacto == 1) {

					if (bossMuerto) {
						efectoBossMuerto.play();
						bossMuerto = 0;
					}

					pantallaX = 1024;
					dibujoEntreacto = 1;
					proyectiles.erase(proyectiles.begin(), proyectiles.end());
					obstaculos.erase(obstaculos.begin(), obstaculos.end());
					disparos.erase(disparos.begin(), disparos.end());
					
				}
				else if (vidaBoss <= 0 && entreacto == 0) {

					bossMuerto = 1;
					dibujoEntreacto = 0;
					game_state = "minijuego";
					tipoMinijuego = "matatopos";
					primeraVezMinijuego = 1;

				}
			

			if (vida == 0) {

				game_state = "gameover";

			}

		}


	}
	else if (gamePhase == "nivel3") {
			
			nombreBoss = "anonymous";
			nombreBossD = "anonymous";
			escenario = planta2;
			disparo = ArmaTel;
			proyectil[0] = proyectilesTel[0];
			proyectil[1] = proyectilesTel[1];
			obstaculo[0] = obstaculosTel[0];
			obstaculo[1] = obstaculosTel[1];
			videoAcabado = escenario.getIsMovieDone();

			cambioPantalla();

			if (primeraVez) {

				primeraVez = 0;
				timer = ofGetElapsedTimef();
				vidaBoss = 4;
				entreacto = 1;
				numeroR = 1;
			}

			
			disparoPersonaje();
			generacionProyectilesObstaculos();
			proyectilesObstaculos();

			if (videoAcabado) {

				peleaBoss(nombreBoss);

				if (vidaBoss <= 0 && entreacto == 1) {

					if (bossMuerto) {
						efectoBossMuerto.play();
						bossMuerto = 0;
					}

					pantallaX = 1024;
					dibujoEntreacto = 1;
					proyectiles.erase(proyectiles.begin(), proyectiles.end());
					obstaculos.erase(obstaculos.begin(), obstaculos.end());
					disparos.erase(disparos.begin(), disparos.end());
					
								
				}
				else if (vidaBoss <= 0 && entreacto == 0) {
					
					bossMuerto = 1;
					dibujoEntreacto = 0;
					game_state = "minijuego";
					tipoMinijuego = "puzzle";
					primeraVezMinijuego = 1;
				}
			}

			if (vida == 0) {

				game_state = "over";
												
			}

	}
	else if (gamePhase == "nivel4") {
			
			nombreBoss = "superOrdenador";
			nombreBossD = "superOrdenador";
			escenario = planta1;
			disparo = ArmaInf;
			proyectil[0] = proyectilesInf[0];
			proyectil[1] = proyectilesInf[1];
			obstaculo[0] = obstaculosInf[0];
			obstaculo[1] = obstaculosInf[1];
			videoAcabado = escenario.getIsMovieDone();

			cambioPantalla();

			if (primeraVez) {

				primeraVez = 0;
				timer = ofGetElapsedTimef();
				vidaBoss = 4;
				entreacto = 1;
				numeroR = 1;
			}

			
			disparoPersonaje();
			generacionProyectilesObstaculos();
			proyectilesObstaculos();

			if (videoAcabado) {

				peleaBoss(nombreBoss);

				if (vidaBoss <= 0 && entreacto == 1) {

					if (bossMuerto) {
						efectoBossMuerto.play();
						bossMuerto = 0;
					}

					pantallaX = 1024;
					dibujoEntreacto = 1;
					proyectiles.erase(proyectiles.begin(), proyectiles.end());
					obstaculos.erase(obstaculos.begin(), obstaculos.end());
					disparos.erase(disparos.begin(), disparos.end());
					
				}
				else if (vidaBoss <= 0 && entreacto == 0) {

					bossMuerto = 1;
					dibujoEntreacto = 0;
					game_state = "minijuego";
					tipoMinijuego = "snake";
					primeraVezMinijuego = 1;

				}
			}

			if (vida == 0) {

				game_state = "gameover";
								
			}

		

	}
	else if (gamePhase == "nivel5") {
			
		nombreBossD = "adaByron";
		escenario = sotano;
		disparo = ArmaSot;
		videoAcabado = escenario.getIsMovieDone();
		int eleccion = ofRandom(1, 4);

		cambioPantalla();

		if (primeraVez) {

			primeraVez = 0;
			timer = ofGetElapsedTimef();
			vidaBoss = 4;
			entreacto = 1;
			numeroR = 1;
		}

		if (eleccion == 1) {

			proyectil[0] = proyectilesInf[0];
			proyectil[1] = proyectilesInf[1];

			obstaculo[0] = obstaculosInf[0];
			obstaculo[1] = obstaculosInf[1];
		}
		else if (eleccion == 2) {

			proyectil[0] = proyectilesElec[0];
			proyectil[1] = proyectilesElec[1];

			obstaculo[0] = obstaculosElec[0];
			obstaculo[1] = obstaculosElec[1];

		}
		else if (eleccion == 3) {

			proyectil[0] = proyectilesTel[0];
			proyectil[1] = proyectilesTel[1];

			obstaculo[0] = obstaculosTel[0];
			obstaculo[1] = obstaculosTel[1];

		}
		else if (eleccion == 4) {

			proyectil[0] = proyectilesCom[0];
			proyectil[1] = proyectilesCom[1];

			obstaculo[0] = obstaculosCom[0];
			obstaculo[1] = obstaculosCom[1];

		}

		
		ofRemove(disparos, ofxBox2dBaseShape::shouldRemoveOffScreen);
		ofRemove(obstaculos, ofxBox2dBaseShape::shouldRemoveOffScreen);
		ofRemove(proyectiles, ofxBox2dBaseShape::shouldRemoveOffScreen);
		disparoPersonaje();
		generacionProyectilesObstaculos();
		proyectilesObstaculos();

		if (videoAcabado) {
				
			if (firstTime) {

				timerAda = ofGetElapsedTimef();
				firstTime = 0;

			}

			if (ofGetElapsedTimef() - timerAda >= 2) {
				timerAda = ofGetElapsedTimef();
				nombreBoss = bosses[index];
				index++;
				if (index >= 4) {

					index = 0;

				}

			}

			peleaBoss(nombreBoss);

			if (vidaBoss <= 0 && entreacto == 1) {

				if (bossMuerto) {
					efectoBossMuerto.play();
					bossMuerto = 0;
				}
				
				pantallaX = 1024;
				dibujoEntreacto = 1;
				proyectiles.erase(proyectiles.begin(), proyectiles.end());
				obstaculos.erase(obstaculos.begin(), obstaculos.end());
				disparos.erase(disparos.begin(), disparos.end());
				

			}
			else if (vidaBoss <= 0 && entreacto == 0) {

				bossMuerto = 1;
				dibujoEntreacto = 0;
				game_state = "minijuego";
				tipoMinijuego = "espejos";
				primeraVezMinijuego = 1;

			}
		}

		if (vida == 0) {
			pantallaX = 1024;
			game_state = "gameover";
			
		}

	}

	//new_x = mouseX-1024;
	//new_y = mouseY;
	//mapa
	//obstaculos
	//minijuego
	//boss

}


void ofApp::setupMinijuegoCables() {

	img.load("Arreglar_Cableado.png");
	img_roja.load("cable_rojo.png");
	img_azul.load("cable_azul.png");
	img_amarilla.load("cable_amarillo.png");
	img_morada.load("cable_morado.png");
	game_stateCables = "start";
	//start_to_game = ofGetElapsedTimef();
	interval_to_start = 1;
	cables_random = { 145 - 8,325 - 30,460,640 - 30 };
	pos_rojo = round(ofRandom(0, 3));
	pos_azul = pos_rojo + 1;
	pos_amarillo = pos_rojo + 2;
	pos_morado = pos_rojo + 3;
	posiciones = { pos_rojo,pos_azul,pos_amarillo,pos_morado };
	for (int i = 0; i < 4; i++) {
		if (posiciones[i] > 3) {
			posiciones[i] = posiciones[i] - 4;
		}
	}

}

void ofApp::drawMinijuegoCables() {
	ofSetColor(255, 255, 255);

	if (game_stateCables == "start") {
		img.draw(0, 0, 1024, 768);

	}
	else if (game_stateCables == "game") {
		img.draw(0, 0,1024, 768);
		img_roja.draw(900 - 60, cables_random[posiciones[0]]);
		img_azul.draw(900 - 55, cables_random[posiciones[1]]);
		img_amarilla.draw(900 - 55, cables_random[posiciones[2]]);
		img_morada.draw(900 - 60, cables_random[posiciones[3]]);
		if (estoyPintando == true) {
			if (color == "rojo") {
				ofSetColor(255, 0, 0);
			}
			else if (color == "amarillo") {
				ofSetColor(255, 242, 0);
			}
			else if (color == "morado") {
				ofSetColor(255, 0, 255);
			}
			else if (color == "azul") {
				ofSetColor(0, 0, 255);
			}
			ofSetLineWidth(30);
			ofDrawLine(cable, p);
		}
		if (color == "rojo" && rojo == true) {
			ofSetColor(255, 0, 0);
			ofSetLineWidth(30);
			ofDrawLine(cable, p);
			cable1 = cable;
			p1 = p;
			color = "";
		}
		else if (color == "amarillo" && amarillo == true) {
			ofSetColor(255, 242, 0);
			ofSetLineWidth(30);
			ofDrawLine(cable, p);
			cable2 = cable;
			p2 = p;
			color = "";
		}
		else if (color == "morado" && morado == true) {
			ofSetColor(255, 0, 255);
			ofSetLineWidth(30);
			ofDrawLine(cable, p);
			cable3 = cable;
			p3 = p;
			color = "";
		}
		else if (color == "azul" && azul == true) {
			ofSetColor(0, 0, 255);
			ofSetLineWidth(30);
			ofDrawLine(cable, p);
			cable4 = cable;
			p4 = p;
			color = "";
		}

		if (rojo == true) {
			ofSetColor(255, 0, 0);
			ofSetLineWidth(30);
			ofDrawLine(cable1, p1);
		}
		if (amarillo == true) {
			ofSetColor(255, 242, 0);
			ofSetLineWidth(30);
			ofDrawLine(cable2, p2);
		}
		if (morado == true) {
			ofSetColor(255, 0, 255);
			ofSetLineWidth(30);
			ofDrawLine(cable3, p3);
		}
		if (azul == true) {
			ofSetColor(0, 0, 255);
			ofSetLineWidth(30);
			ofDrawLine(cable4, p4);
		}
	}
	if (game_stateCables == "end") {
		img.draw(0, 0, 1024, 768);

	}
	ofSetColor(255, 255, 255);

}

	void ofApp::minijuegoCablesUpdate() {

		if (game_stateCables == "start") {
			if ((ofGetElapsedTimef() - start_to_game) > interval_to_start) {
				game_stateCables = "game";
			}
		}
		else if (game_stateCables == "game") {
			
			if (cablesBotonPrieto) {

				mouseDraggedCables();

			}

			if (rojo == true && amarillo == true && morado == true && azul == true) {
				game_stateCables = "end";
				
			
			}
		}


	}

	void ofApp::mouseDraggedCables() {

		int x = new_x;
		int y = new_y;

		if (game_stateCables == "game") {
			p.set(x, y, 0);

			if (color == "amarillo" && estoyPintando == true && (ofDist(x, y, 900, cables_random[posiciones[2]]) < ((2 * 30.0f) / 2)) && amarillo == false) {
				estoyPintando = false;
				amarillo = true;

			}
			else if (color == "rojo" && estoyPintando == true && (ofDist(x, y, 900, cables_random[posiciones[0]]) < ((2 * 30.0f) / 2)) && rojo == false) {
				estoyPintando = false;
				rojo = true;
			}
			else if (color == "morado" && estoyPintando == true && (ofDist(x, y, 900, cables_random[posiciones[3]]) < ((2 * 30.0f) / 2)) && morado == false) {
				estoyPintando = false;
				morado = true;
			}
			else if (color == "azul" && estoyPintando == true && (ofDist(x, y, 900, cables_random[posiciones[1]]) < ((2 * 30.0f) / 2)) && azul == false) {
				estoyPintando = false;
				azul = true;
			}
		}


	}

	void ofApp::mousePressedCables() {

		int x = new_x;
		int y = new_y;

		if (game_stateCables == "game") {

			if (ofDist(x, y, 100, 155) < ((2 * 30.0f) / 2) && estoyPintando == false && amarillo == false) {
				estoyPintando = true;
				p.set(x, y, 0);
				cable.set(100, 155, 0);
				color = "amarillo";

			}
			else if (ofDist(x, y, 100, 315) < ((2 * 30.0f) / 2) && estoyPintando == false && rojo == false) {
				estoyPintando = true;
				p.set(x, y, 0);
				cable.set(100, 315, 0);
				color = "rojo";

			}
			else if (ofDist(x, y, 100, 470) < ((2 * 30.0f) / 2) && estoyPintando == false && morado == false) {
				estoyPintando = true;
				p.set(x, y, 0);
				cable.set(100, 470, 0);
				color = "morado";

			}
			else if (ofDist(x, y, 100, 630) < ((2 * 30.0f) / 2) && estoyPintando == false && azul == false) {
				estoyPintando = true;
				p.set(x, y, 0);
				cable.set(100, 630, 0);
				color = "azul";

			}
		}


	}
	
	
	void ofApp::mouseReleasedCables() {

		estoyPintando = false;
		//borrar linea


	}

	void ofApp::fboIn() {

		if(game_state == "menu"|| game_state=="inicio"|| game_state == "nivel1" || game_state == "nivel2" || game_state == "nivel3" || game_state == "nivel4" || game_state == "nivel5"||game_state=="minijuego"){
		
			if (dibujoEntreacto) {

				/*if (agachado == true) {

					ofDrawBitmapString("agachado", 10, 90);

				}
				else {

					ofDrawBitmapString("de pie", 10, 90);

				}*/

				entreactoDraw();

			}

			else {

				escenario.draw(0, 0, 1024, 768);

				/*if (agachado == true) {

					ofDrawBitmapString("agachado", 10, 90);

				}
				else {

					ofDrawBitmapString("de pie", 10, 90);

				}*/

				/*ofDrawBitmapString(ofToString(colisiones), 30, 30);
				ofDrawBitmapString(ofToString(point.x), 30, 40);
				ofDrawBitmapString(ofToString(point.y), 30, 50);
				ofDrawBitmapString(ofToString(vidaBoss), 30, 60);
				ofDrawBitmapString(ofToString(vida), 30, 70);
				ofDrawBitmapString(ofToString(ofGetFrameRate()),30,150);*/

				drawPersonaje();
				drawDisparos();


				drawObstaculosProyectiles(1, proyectil);
				drawObstaculosProyectiles(3, obstaculo);



				if (videoAcabado) {

					/*if (agachado == true) {

						ofDrawBitmapString("agachado", 10, 60);

					}
					else {

						ofDrawBitmapString("de pie", 10, 60);

					}*/

					colisionBoss();
					drawPeleaBoss(nombreBossD);

				}
			}
		}
		else if (game_state == "gameover"){


			gameOver.draw(0, 0, 1024, 768);

		}
		else if (game_state == "final") {

			ending.draw(0, 0, 1024, 768);
			musicaFondo.stop();

			if (endingPrimera) {

				efectoEnding.play();
				endingPrimera = 0;

			}

		}

		ofDrawCircle(new_x, new_y, 8);

	}

	void ofApp::cambioPantalla() {

		
		if (primeraVez) {

			timerCambio = ofGetElapsedTimef();

		}
		
		if (ofGetElapsedTimef() - timerCambio >= 20) {

			numeroR = ofRandom(0, 3);
			timerCambio = ofGetElapsedTimef();

		}

		if (numeroR == 0) {

			pantallaX = 0;
			pantallaY = 0;

		}
		else if (numeroR == 1) {

			pantallaX = 1024;
			pantallaY = 0;

		}
		else if (numeroR == 2) {

			pantallaX = 2048;
			pantallaY = 0;

		}
		

	}

	void ofApp::oscReceiverPoints() {

		// check for waiting OSC messages
		while (oscReceiver.hasWaitingMessages()) {

			// get the next message
			ofxOscMessage m;
			oscReceiver.getNextMessage(m);

			// check messages of interest
			if (m.getAddress() == "/mediapipe_osc_server/pose/tracking") {
				is_tracking_pose = m.getArgAsBool(0);
			}

			else if (m.getAddress() == "/mediapipe_osc_server/pose/24") {
				right_hip.x = m.getArgAsFloat(0);
				right_hip.y = m.getArgAsFloat(1);
			}					

		}

		ofPoint point;

		if (right_hip.x != 0) {

			if (inicializado == true) {

				point.set(right_hip.x, right_hip.y);
				inicializacionOsc(right_hip);
				inicializado = false;

			}
			else {

				point.set(right_hip.x, right_hip.y);
				detAgachado(point);
				
			}

		}

	}


	void ofApp::inicializacionOsc(ofPoint point) {

		calibracion_inicial = point;
		ultimo_punto = point.y;
		clock_t t0 = clock();

	}

	void ofApp::detAgachado(ofPoint point) {

		if ((point.y > phi1 * calibracion_inicial.y) && agachado == false) {

			agachado = true;
		}
		else if ((point.y < phi1 * calibracion_inicial.y) && agachado == true) {

			agachado = false;

		}

	}

	void ofApp::psMoveUpdate() {

		navigationAngles = psMoveServerClient.get_navigationAngles(controller_in_screen);

		double yaw = navigationAngles.x;
		double pitch = navigationAngles.y;


		new_x = ofMap(yaw + desfase, -PI / 4 + desfase, PI / 4 + desfase, 0, 1024);
		new_y = ofMap(pitch, PI / 4, -PI / 4, 0, 768);

	}

	void ofApp::setupMatatopos() {
		game_stateMatatopos = "start";
		enemy_image.loadImage("lacasito_amarillo.png");
		martillo.loadImage("martillo.png");
		start_screen.loadImage("cielo.jpg");
		width_topo = enemy_image.getWidth();
		start_to_gameMatatopos = ofGetElapsedTimef();
		interval_to_startMatatopos = 5;
		topos_size = 2;
		for (int i = 0; i < topos_size; i++) {
			topo.setupTopo(&enemy_image);
			topos.push_back(topo);
		}
	}

	void ofApp::updateMatatopos() {
		if (game_stateMatatopos == "start") {
			if ((ofGetElapsedTimef() - start_to_gameMatatopos) > interval_to_startMatatopos) {
				game_stateMatatopos = "game";
			}
		}
		else if (game_stateMatatopos == "game") {

			for (int i = 0; i < topos_size; i++) {
				topos[i].updateTopo();
			}
		}
	}

	void ofApp::drawMatatopos() {
		if (game_stateMatatopos == "start") {
			start_screen.draw(0, 0, 1024, 768);
		}
		else if (game_stateMatatopos == "game") {
			start_screen.draw(0, 0, 1024,768);
			martillo.draw(pos_x_martillo, pos_y_martillo - 40, 100, 200);
			ofDrawBitmapString("Puntos:", 10, 10);
			ofDrawBitmapString(score, 100, 10);
			for (int i = 0; i < topos_size; i++) {
				topos[i].drawTopo();
				if (topos[i].verifyTopo() == false) {
					cont = cont + 1;
					if (cont == topos_size) {
						for (int i = 0; i < topos_size; i++) {
							topos.erase(topos.begin() + i);
							topo.setupTopo(&enemy_image);
							topos.push_back(topo);
							score_total = score_total + 1;
							if (score_total >= 60) {
								game_stateMatatopos = "end";
							}
						}

						cont = 0;
					}
				}
			}
		}
		else if (game_stateMatatopos == "end") {
			start_screen.draw(0, 0);
			ofDrawBitmapString("Has conseguido una puntuaci�n de ", 10, 10);
			ofDrawBitmapString(score, 500, 10);
		}

	}

	void ofApp::mousePressedMatatopos() {
		int x = new_x;
		int y = new_y;
		
		if (game_stateMatatopos == "game") {
			if (score == 4) {
				topos_size = 3;
				topo.setupTopo(&enemy_image);
				topos.push_back(topo);
			}
			else if (score == 9) {
				topos_size = 4;
				topo.setupTopo(&enemy_image);
				topos.push_back(topo);
			}
			else if (score == 14) {
				topos_size = 5;
				topo.setupTopo(&enemy_image);
				topos.push_back(topo);
			}
			for (int i = 0; i < topos_size; i++) {
				if (ofDist(x, y, topos[i].posTopo.x, topos[i].posTopo.y) < ((2 * 70.0f) / 2)) {
					score = score + 1;
					topos.erase(topos.begin() + i);
					topo.setupTopo(&enemy_image);
					topos.push_back(topo);
					score_total = score_total + 1;
				}
			}
			//float width_topo = enemy_image->getWidth();
			//float width_martillo = martillo->getWidth();
			//martillo->draw(x - width_martillo / 2, y - width_martillo / 2);
		}
	}

	void ofApp::setupMinijuegoPuzzle() {
		imgPuzzle.load("Captura.png"); // x=1024 , y=768, w=500, h=300 


		UWin.load("UWin.jpg");


		x = (1024 - imgPuzzle.getWidth()) * 0.5;       // center on screen.
		y = (768 - imgPuzzle.getHeight()) * 0.5;     // center on screen.
		wPuzzle = imgPuzzle.getWidth();
		h = imgPuzzle.getHeight();
		i = 0;
		j = 0;
		on = 0;
		pieza = 0;
		direccion = 1;
		cnt = 0;
		//Imagen 1
		Posx = 0;
		Posy = 0;
		cnt1 = 0;
		//Imagen 2
		Pos1x = 0;
		Pos1y = 0;
		cnt2 = 0;
		//Imagen 3
		Pos2x = 0;
		Pos2y = 0;
		cnt3 = 0;
		//Imagen 4
		Pos3x = 0;
		Pos3y = 0;
		cnt4 = 0;
		//Imagen 5
		Pos4x = 0;
		Pos4y = 0;
		cnt5 = 0;
		//Imagen 6
		Pos5x = 0;
		Pos5y = 0;
		cnt6 = 0;




		dist_X = wPuzzle / N_X;
		dist_Y = h / N_Y;



		for (int i = 0; i < N_X; i++) {
			for (int j = 0; j < N_Y; j++) {
				imgs[i][j].cropFrom(imgPuzzle, i * dist_X, j * dist_Y, dist_X, dist_Y);
				warper[i][j].setSourceRect(ofRectangle(0, 0, dist_X, dist_Y));              // this is the source rectangle which is the size of the image and located at ( 0, 0 )
				warper[i][j].setTopLeftCornerPosition(ofPoint(x + (i * dist_X), y + (j * dist_Y)));             // this is position of the quad warp corners, centering the image on the screen.
				warper[i][j].setTopRightCornerPosition(ofPoint(x + (i * dist_X) + dist_X, y + (j * dist_Y)));        // this is position of the quad warp corners, centering the image on the screen.
				warper[i][j].setBottomLeftCornerPosition(ofPoint(x + (i * dist_X), y + (j * dist_Y) + dist_Y));      // this is position of the quad warp corners, centering the image on the screen.
				warper[i][j].setBottomRightCornerPosition(ofPoint(x + (i * dist_X) + dist_X, y + (j * dist_Y) + dist_Y)); // this is position of the quad warp corners, centering the image on the screen.
				warper[i][j].setup();
			}
		}
	}

	void ofApp::drawMinijuegoPuzzle() {
		ofSetColor(255, 255, 255);
		string info = "";
		info += "Press [triangle] to rotate the piece \n";
		info += "Press [square] to control the next piece  \n";
		ofDrawBitmapString(info, 10, 10);

		if (keyC) {
			keyC = false;

			if (j == 0 && i == 0) {
				if (on == 1) {
					warper[2][1].toggleShow();
				}
				warper[i][j].toggleShow();
				i++;
				pieza = 1;
			}
			else if (j == 0 && i == 1) {
				warper[0][0].toggleShow();
				warper[i][j].toggleShow();
				i++;
				pieza = 2;
			}
			else if (j == 0 && i == 2) {
				warper[1][0].toggleShow();
				warper[i][j].toggleShow();
				i = 0;
				j++;
				pieza = 3;
			}
			else if (j == 1 && i == 0) {
				warper[2][0].toggleShow();
				warper[i][j].toggleShow();
				i++;
				pieza = 4;
			}
			else if (j == 1 && i == 1) {
				warper[0][1].toggleShow();
				warper[i][j].toggleShow();
				i++;
				pieza = 5;
			}
			else {
				warper[1][1].toggleShow();
				warper[i][j].toggleShow();
				i = 0;
				j = 0;
				on = 1;
				pieza = 6;
			}







		}

		if (keyX) {
			keyX = false;
			if (pieza == 0 || pieza == 6) {
				Posx = x;
				Posy = y;
				if (direccion == 0) {
					direccion = 1;
					Imagen.load("fila-1-columna-1.png");
					cnt1 = 1;
				}
				else {
					direccion = 0;
					Imagen.load("fila-1-columna-1DD.png");
					cnt1 = 0;
				}
			}
			if (pieza == 1) {

				Pos1x = x + dist_X;
				Pos1y = y;
				if (direccion == 0) {
					direccion = 1;
					Imagen2.load("fila-1-columna-2.png");
					cnt2 = 1;
				}
				else {
					direccion = 0;
					Imagen2.load("fila-1-columna-2DD.png");
					cnt2 = 0;
				}
			}
			if (pieza == 2) {
				Pos2x = x + 2 * dist_X;
				Pos2y = y;
				if (direccion == 0) {
					direccion = 1;
					Imagen3.load("fila-1-columna-3.png");
					cnt3 = 1;

				}
				else {
					direccion = 0;
					Imagen3.load("fila-1-columna-3DD.png");
					cnt3 = 0;
				}
			}
			if (pieza == 3) {
				Pos3x = x;
				Pos3y = y + dist_Y;
				if (direccion == 0) {
					direccion = 1;
					Imagen4.load("fila-2-columna-1.png");
					cnt4 = 1;

				}
				else {
					direccion = 0;
					Imagen4.load("fila-2-columna-1DD.png");
					cnt4 = 0;
				}
			}
			if (pieza == 4) {
				Pos4x = x + dist_X;
				Pos4y = y + dist_Y;
				if (direccion == 0) {
					direccion = 1;
					Imagen5.load("fila-2-columna-2.png");
					cnt1 = 1;

				}
				else {
					direccion = 0;
					Imagen5.load("fila-2-columna-2DD.png");
					cnt5 = 0;
				}
			}
			if (pieza == 5) {
				Pos5x = x + 2 * dist_X;
				Pos5y = y + dist_Y;
				if (direccion == 0) {
					direccion = 1;
					Imagen6.load("fila-2-columna-3.png");
					cnt6 = 1;

				}
				else {
					direccion = 0;
					Imagen6.load("fila-2-columna-3DD.png");
					cnt6 = 0;
				}
			}



		}

		Imagen.draw(Posx, Posy);
		Imagen2.draw(Pos1x, Pos1y);
		Imagen3.draw(Pos2x, Pos2y);
		Imagen4.draw(Pos3x, Pos3y);
		Imagen5.draw(Pos4x, Pos4y);
		Imagen6.draw(Pos5x, Pos5y);
		cnt = cnt1 + cnt2 + cnt3 + cnt4 + cnt5 + cnt6;
		if (cnt == 5) {//La dibujo tantas veces para simular el efecto de un error
			UWin.draw(Posx, Posy);
			UWin.draw(Pos3x, Pos3y);
			UWin.draw(Pos5x, Pos5y);
			UWin.draw(Pos2x, Pos2y);
			UWin.draw(Pos1x, Pos1y);
			UWin.draw(Pos4x, Pos4y);
			game_statePuzzle = "end";
		}

		ofSetColor(ofColor::magenta);
		warper[i][j].drawQuadOutline();

		ofSetColor(ofColor::yellow);
		warper[i][j].drawCorners();

		ofSetColor(ofColor::magenta);
		warper[i][j].drawHighlightedCorner();

		ofSetColor(ofColor::red);
		warper[i][j].drawSelectedCorner();

		ofSetColor(ofColor::white);


	}

	void ofApp::minijuegoPuzzleUpdate() {

		if (cnt == 5) {
			game_statePuzzle = "end";
		}
	}

	void ofApp::setupMinijuegoSnake() {
		srand(static_cast<unsigned>(time(0))); // Seed random with current time
	}

	void ofApp::drawMinijuegoSnake() {
		ofSetColor(255, 255, 255);
		ofDrawRectangle(0, 0, 1024, 768);
		if (current_state_ == PAUSED) {

			drawGamePaused();
		}
		else if (current_state_ == FINISHED) {
			drawTopTen();
			drawGameOver();

		}

		drawFood();
		drawSnake();
	}

	void ofApp::minijuegoSnakeUpdate() {
		
		game_food_.resize(1000, 1000);
		
		if (should_update_) {

			if (current_state_ == IN_PROGRESS) {

				ofVec2f snake_body_size = game_snake_.getBodySize();
				ofVec2f head_pos = game_snake_.getHead()->position;
				ofRectangle snake_rect(head_pos.x, head_pos.y, snake_body_size.x, snake_body_size.y);

				if (snake_rect.intersects(game_food_.getFoodRect())) {
					game_snake_.eatFood(game_food_.getColor());
					game_food_.rebase();
				}
				game_snake_.update();
				string total_food = std::to_string(game_snake_.getFoodEaten());
				if (ofToInt(total_food) >= 4) {
					game_stateSnake = "end";
					current_state_ = FINISHED;
					updateScores();
				}

				if (game_snake_.isDead()) {
					game_stateSnake = "end";
					current_state_ = FINISHED;
					updateScores();
				}
			}
		}

		should_update_ = true;
	}

	void ofApp::updateScores() {
		string total_food = std::to_string(game_snake_.getFoodEaten());
		int sum_food = stoi(total_food);
		gameScores.push_back(sum_food);
	}

	void ofApp::reset() {

		speed = speed + 12;
		ofSetFrameRate(speed);
		gameSound.load("b.mp3");  //added some sound here
		gameSound.play();
		game_snake_ = Snake();
		game_food_.rebase();

		current_state_ = IN_PROGRESS;

	}

	void ofApp::windowResizedSnake(int w, int h) {
		game_food_.resize(w, h);
		game_snake_.resize(w, h);
	}

	void ofApp::drawFood() {
		ofSetColor(game_food_.getColor());
		ofDrawRectangle(game_food_.getFoodRect());
	}

	void ofApp::drawSnake() {
		ofVec2f snake_body_size = game_snake_.getBodySize();
		ofVec2f head_pos = game_snake_.getHead()->position;
		ofSetColor(game_snake_.getHead()->color);
		ofDrawRectangle(head_pos.x, head_pos.y, snake_body_size.x, snake_body_size.y);

		for (SnakeBody* curr = game_snake_.getHead(); curr != NULL; curr = curr->next) {
			ofVec2f currPos = curr->position;
			ofSetColor(curr->color);
			ofDrawRectangle(currPos.x, currPos.y, snake_body_size.x, snake_body_size.y);
		}
	}

	void ofApp::drawGameOver() {
		ofSetColor(255, 255, 255);
		string total_food = std::to_string(game_snake_.getFoodEaten());
		string lose_message = "You Lost! Final Score: " + total_food;
		string win_message = "You Win! Final Score: " + total_food;
		drawTopTen();
		if (ofToInt(total_food) >= 5) {
			ofSetColor(0, 0, 0);
			ofDrawBitmapString(win_message, ofGetWindowWidth() / 2, ofGetWindowHeight() / 2);
		}
		else {
			ofSetColor(0, 0, 0);
			ofDrawBitmapString(lose_message, ofGetWindowWidth() / 2, ofGetWindowHeight() / 2);
		}


	}

	void ofApp::drawGamePaused() {

		if (!pressedH) {
			drawTopTen();
		}
		string pause_message = "H to Unpause!";
		ofSetColor(0, 0, 0);
		ofDrawBitmapString(pause_message, ofGetWindowWidth() / 2, ofGetWindowHeight() / 2);
	}

	void ofApp::drawTopTen() {
		string output;
		std::sort(gameScores.rbegin(), gameScores.rend());
		for (int i = 0; i < gameScores.size() && i < 5; i++) {
			string score = to_string(gameScores[i]);
			std::string number = std::to_string(i + 1);
			output += number + "-" + score + '\n';

			ofDrawBitmapString(output, ofGetWindowWidth() / 2, ofGetWindowHeight() / 2 + 7);
		}
	}

	void ofApp::keyPressedSnake(int key) {

		int upper_key = toupper(key); // Standardize on upper case

		if (current_state_ == IN_PROGRESS)
		{

			SnakeDirection current_direction = game_snake_.getDirection();

			// If current direction has changed to a valid new one, force an immediate update and skip the next frame update
			if ((upper_key == 'W' || key == OF_KEY_UP) && current_direction != DOWN && current_direction != UP) {
				game_snake_.setDirection(UP);

				update();
				should_update_ = false;
			}
			else if ((upper_key == 'A' || key == OF_KEY_LEFT) && current_direction != RIGHT && current_direction != LEFT) {
				game_snake_.setDirection(LEFT);
				update();
				should_update_ = false;
			}
			else if ((upper_key == 'S' || key == OF_KEY_DOWN) && current_direction != UP && current_direction != DOWN) {
				game_snake_.setDirection(DOWN);
				update();
				should_update_ = false;
			}
			else if ((upper_key == 'D' || key == OF_KEY_RIGHT) && current_direction != LEFT && current_direction != RIGHT) {
				game_snake_.setDirection(RIGHT);
				update();
				should_update_ = false;
			}
			else if (key == OF_KEY_BACKSPACE && current_direction == UP) {
				game_snake_.setDirection(LEFT);
			}
			else if (key == OF_KEY_BACKSPACE && current_direction == LEFT) {
				game_snake_.setDirection(DOWN);
			}
			else if (key == OF_KEY_BACKSPACE && current_direction == DOWN) {
				game_snake_.setDirection(RIGHT);
			}
			else if (key == OF_KEY_BACKSPACE && current_direction == RIGHT) {
				game_snake_.setDirection(UP);
			}

		}
		else if (upper_key == 'R' && current_state_ == FINISHED) {

			reset();
		}
	}

	void ofApp::setupMinijuegoEspejos() {
		soundEspejos.load("contacto.mp3");
		soundEspejos.setMultiPlay(true);
		youWin.load("youWin.jpg");
		cielo.load("cielo.jpg");
		mirror.load("mirror.png");
		cannon.load("laser_cannon_2_45.png");
		antenna.load("antenna_trans.png");
		antenna2.load("antenna2_trans.png");
		lacasitosImagenes[0].load("mirror.png");
		lacasitosImagenes[1].load("mirror.png");
		lacasitosImagenes[2].load("mirror.png");
		lacasitosImagenes[3].load("mirror.png");

		posXPuzzle = 640;
		posYPuzzle = 640;

		box2dEspejos.init();
		box2dEspejos.setGravity(0, 0);
		box2dEspejos.createGround();
		box2dEspejos.setFPS(60.0);
		box2dEspejos.registerGrabbing();
		box2dEspejos.enableEvents();   // <-- turn on the event listener

		pretadoEspejos = false;

		// register the listener so that we get the events
		/*ofAddListener(box2dEspejos.contactStartEvents, this, &ofApp::contactStartEspejos);
		ofAddListener(box2dEspejos.contactEndEvents, this, &ofApp::contactEnd);*/
	}

	void ofApp::drawMinijuegoEspejos() {
		ofSetColor(255, 255, 255);
		//ofSetColor(184, 37, 53, 255);
		//ofDrawRectangle(0, 0, 1024, 768);
		ofSetColor(255, 255, 255);
		//cielo.draw(0, 0, ofGetWidth(), ofGetHeight());
		ofSetColor(255, 255, 255);
		cannon.draw(-115, -118);
		ofSetColor(255, 255, 255);
		antenna.draw(50, 600);

		/*ofSetColor(0, 0, 0);
		ofDrawBitmapString(coordX, 10, 35);
		ofDrawBitmapString(coordY, 10, 50);*/

		ofSetColor(0, 0, 0);
		string info = "";
		info += "Point the laser to the antenna \n";
		info += "Press [x] if you need a mirror \n";
		ofDrawBitmapString(info, 10, 10);
		ofSetColor(255, 255, 255);

		for (int i = 0; i < lacasitos.size(); i++) {
			ofPushMatrix();
			ofTranslate(lacasitos[i]->getPosition().x, lacasitos[i]->getPosition().y, 0);
			int color = lacasitos[i]->color;
			lacasitosImagenes[color].draw(-4 * RADIO_LACASITO, -4 * RADIO_LACASITO, 8 * RADIO_LACASITO, 8 * RADIO_LACASITO);
			ofPopMatrix();
		}

		ofSetColor(255, 0, 0);
		ofFill();
		//ofDrawRectangle(300, 300, 5, 10, 10);
		//ofRotate(45);
		ofSetLineWidth(100);
		ofDrawLine(280, 280, posXPuzzle, posYPuzzle);
		if (contacto) {
			ofSetColor(255, 0, 0);
			ofFill();
			ofSetLineWidth(18);
			//ofDrawLine(posX, posY, -posY, posX);
			//ofDrawLine(posX+5, posY, 235, 640);
			ofDrawLine(posXPuzzle + 5, posYPuzzle, -posYPuzzle + 850, posXPuzzle + 10);
			coordX = posXPuzzle;
			coordY = posYPuzzle;
		}

		if (coordX >= 620 && coordX <= 635) {
			//string win= "You win!";
			ofSetColor(255, 255, 255);
			//ofDrawBitmapString(win, 10, 35);
			youWin.draw(1024 / 2, 768 / 2 - 150);
			endEspejos = true;
			//ofDrawBitmapString(win, ofGetWindowWidth() / 2, ofGetWindowHeight() / 2);
			game_stateEspejos = "end";
		}
	}

	void ofApp::minijuegoEspejosUpdate() {

		box2dEspejos.update();
		
		if (pretadoEspejos) {

			mouseDraggedEspejos();

		}
		
		
		if (endEspejos) {
			game_stateEspejos = "end";
		}

	}

	void ofApp::mouseDraggedEspejos() {
		b2Vec2 point = ofxBox2d::toB2d(new_x, new_y);
		mouseXPuzzle = new_x;
		mouseYPuzzle = new_y;
		
		if (mouseXPuzzle == mouseYPuzzle) {
			contacto = true;
			posXPuzzle = mouseXPuzzle;
			posYPuzzle = mouseYPuzzle;
		}

		for (int i = 0; i < lacasitos.size(); i++) {

			int posEspejox = lacasitos[i]->getPosition().x;
			int posEspejoY = lacasitos[i]->getPosition().y;
			
			if(lacasitos[i]->body->GetFixtureList()->TestPoint(point)){
			
				lacasitos[i]->setPosition(mouseXPuzzle, mouseYPuzzle);
				
			}	

		}

	}

	void ofApp::dibujarCorazones() {

		/*if (vida == 1) {

			corazon.draw(25, 50,25,25);
			
		}
		if (vida == 2) {

			corazon.draw(25, 25, 25, 25);
			corazon.draw(60, 25, 25, 25);
		}
		if (vida == 3) {

			corazon.draw(25, 25, 25, 25);
			corazon.draw(60, 25, 25, 25);
			corazon.draw(95, 25, 25, 25);
		}
		if (vida == 4) {

			corazon.draw(25, 25, 25, 25);
			corazon.draw(60, 25, 25, 25);
			corazon.draw(95, 25, 25, 25);
			corazon.draw(130, 25, 25, 25);
			
		}
		if (vida == 5) {

			corazon.draw(25, 25, 25, 25);
			corazon.draw(60, 25, 25, 25);
			corazon.draw(95, 25, 25, 25);
			corazon.draw(130, 25, 25, 25);
			corazon.draw(165, 25, 25, 25);
			

		}
		if (vida == 6) {

			corazon.draw(25, 25, 25, 25);
			corazon.draw(60, 25, 25, 25);
			corazon.draw(95, 25, 25, 25);
			corazon.draw(130, 25, 25, 25);
			corazon.draw(165, 25, 25, 25);
			corazon.draw(200, 25, 25, 25);
		}
		if (vida == 7) {

			corazon.draw(25, 25, 25, 25);
			corazon.draw(60, 25, 25, 25);
			corazon.draw(95, 25, 25, 25);
			corazon.draw(130, 25, 25, 25);
			corazon.draw(165, 25, 25, 25);
			corazon.draw(200, 25, 25, 25);
			corazon.draw(235, 25, 25, 25);
		}
		if (vida == 8) {

			corazon.draw(25, 25, 25, 25);
			corazon.draw(60, 25, 25, 25);
			corazon.draw(95, 25, 25, 25);
			corazon.draw(130, 25, 25, 25);
			corazon.draw(165, 25, 25, 25);
			corazon.draw(200, 25, 25, 25);
			corazon.draw(235, 25, 25, 25);
			corazon.draw(270, 25, 25, 25);
		}
		if (vida == 9) {

			corazon.draw(25, 25, 25, 25);
			corazon.draw(60, 25, 25, 25);
			corazon.draw(95, 25, 25, 25);
			corazon.draw(130, 25, 25, 25);
			corazon.draw(165, 25, 25, 25);
			corazon.draw(200, 25, 25, 25);
			corazon.draw(235, 25, 25, 25);
			corazon.draw(270, 25, 25, 25);
			corazon.draw(305, 25, 25, 25);
		}
		if (vida == 10) {

			corazon.draw(25, 25, 25, 25);
			corazon.draw(60, 25, 25, 25);
			corazon.draw(95, 25, 25, 25);
			corazon.draw(130, 25, 25, 25);
			corazon.draw(165, 25, 25, 25);
			corazon.draw(200, 25, 25, 25);
			corazon.draw(235, 25, 25, 25);
			corazon.draw(270, 25, 25, 25);
			corazon.draw(305, 25, 25, 25);
			corazon.draw(340, 25, 25, 25);
		}
		if (vida == 11) {

			corazon.draw(25, 25, 25, 25);
			corazon.draw(60, 25, 25, 25);
			corazon.draw(95, 25, 25, 25);
			corazon.draw(130, 25, 25, 25);
			corazon.draw(165, 25, 25, 25);
			corazon.draw(200, 25, 25, 25);
			corazon.draw(235, 25, 25, 25);
			corazon.draw(270, 25, 25, 25);
			corazon.draw(305, 25, 25, 25);
			corazon.draw(340, 25, 25, 25);
			corazon.draw(375, 25, 25, 25);
		}
		if (vida == 12) {

			corazon.draw(25, 25, 25, 25);
			corazon.draw(60, 25, 25, 25);
			corazon.draw(95, 25, 25, 25);
			corazon.draw(130, 25, 25, 25);
			corazon.draw(165, 25, 25, 25);
			corazon.draw(200, 25, 25, 25);
			corazon.draw(235, 25, 25, 25);
			corazon.draw(270, 25, 25, 25);
			corazon.draw(305, 25, 25, 25);
			corazon.draw(340, 25, 25, 25);
			corazon.draw(375, 25, 25, 25);
		}*/

	for (int i = 0; i < vida; i++) {

		
		corazon.draw(25+35*i, 25, 25, 25);

	}

	}